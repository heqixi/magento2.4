var config = {
    map: {
        '*': {
            bentrizowlcarousel: 'Hiddentechies_Bentriz/js/owl.carousel',
        }
    }
};